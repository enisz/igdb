import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { getTopics } from '../utils/Database';

export default function Home() {
    const [topics, setTopics] = useState([]);

    useEffect(() => {
        console.log("topic");
        setTopics(getTopics());
    }, []);

    return (
        <div className="container">
            <h2 className="title">Getting started is easy!</h2>
            <div className="intro">
                <p>Welcome to prettyDocs. This landing page is an example of how you can use a card view to present segments of your documentation. You can customise the icon fonts based on your needs.</p>
                <div className="cta-container">
                    <a className="btn btn-primary btn-cta" href="https://themes.3rdwavemedia.com/bootstrap-templates/startup/prettydocs-free-bootstrap-theme-for-developers-and-startups/" target="_blank"><i className="fas fa-cloud-download-alt"></i> Download Now</a>
                </div>
            </div>
            <div id="cards-wrapper" className="cards-wrapper row">
                { topics.map( value => card(value) ) }
            </div>

        </div>
    );
}

const card = ({id, icon, title, overview, color}) => (
    <div key={id} className={`item item-${color} col-lg-4 col-6`}>
        <div className="item-inner">
            <div className="icon-holder">
                <i className={`icon fa ${icon}`}></i>
            </div>
            <h3 className="title">{title}</h3>
            <p className="intro">{overview}</p>
            <NavLink to={`/documentation/${id}`} className="link">
                <span>
                </span>
            </NavLink>

        </div>
    </div>
);