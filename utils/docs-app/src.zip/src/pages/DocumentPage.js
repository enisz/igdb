import React, { useEffect, useState } from 'react';
import { useLocation, useParams } from 'react-router';
import useBodyClass from '../hooks/useBodyClass';
import { getParagraphs, getTopic } from '../utils/Database';

export default function DocumentPage() {
    const params = useParams();
    const [topic, setTopic] = useState({});
    const [paragraphs, setParagraphs] = useState();

    useEffect(() => {
        setTopic(getTopic(params.document));
        //setParagraphs(getParagraphs(topic.id));

        console.log(getParagraphs(topic.id));
    }, []);

    return (
        <div>
            document page
        </div>
    );
}