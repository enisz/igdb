import React from 'react';
import { Route } from 'react-router-dom';
import useBodyClass from '../../hooks/useBodyClass';

//export default function DocumentationLayout({ component: Component, ...rest }) {
//    useBodyClass("body-blue");

//    return (
//        <div className="doc-wrapper">
//            <Route {...rest} render={ props => <Component {...props} /> } />
//        </div>
//    )
//}


const Layout = ({ children }) => (
    <div className="doc-wrapper">
        {children}
    </div>
);

export default function DocumentationLayout({component: Component, ...rest}) {
    return (
        <Route {...rest} render={props => (
            <Layout>
                <Component {...props} />
            </Layout>
        )} />
    )
}