import React from 'react';
import { Route } from 'react-router-dom';
import useBodyClass from '../../hooks/useBodyClass';

//export default function LandingPageLayout({ component: Component, ...rest }) {
//    useBodyClass("landing-page");

//    return (
//        <section className="cards-section text-center">
//            <Route {...rest} render={ props => <Component {...props} /> } />
//        </section>
//    )
//}

const Layout = ({ children }) => {
    useBodyClass("landing-page");

    return (
        <section className="cards-section text-center">
            {children}
        </section>
    );
}

export default function LandingPageLayout({component: Component, ...rest}) {
    return (
        <Route {...rest} render={props => (
            <Layout>
                <Component {...props} />
            </Layout>
        )} />
    )
}